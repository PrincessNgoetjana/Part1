﻿using System;
using static System.Console;
namespace Lerato_Part1
{


    class Program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();

            bool now = true;
            bool bfound = false;

            while (now)
            {
                WriteLine("\nWelcome" +
                    ", Select the number for the option" +
                    ", E.g '1' : ");
                WriteLine("1. Enter Details");
                WriteLine("2. Display recipe");
                WriteLine("3. Scale recipe");
                WriteLine("4. Reset quantities");
                WriteLine("5. Clear recipe");
                WriteLine("6. Exit");

                int inum1;

                inum1 = Convert.ToInt32(ReadLine());

                if (inum1 == 1)
                {
                    recipe.Details();
                    bfound = true;
                }

                if (inum1 == 2) {
                    recipe.Display();
                    bfound = true;
                }

                if (inum1 == 3)
                {
                    Console.Write("Choose a scale between 0.5, 2, or 3 : ");
                    double Factor;
                    Factor = Convert.ToDouble(ReadLine());
                    recipe.Scale(Factor);
                    bfound = true;
                }

                if (inum1 == 4)
                {
                    bfound = true;
                    recipe.Reset();
                }


                if (inum1 == 5)
                {
                    recipe.Clear();
                    bfound = true;
                }
                if (inum1 == 6) {

                    Environment.Exit(0);
                    bfound = true;
                }
                      
                  if (bfound == false)
                        WriteLine("Invalid input");
                        
               
            }
        }
    }


    class Recipe
    {
        private int numING;
        private int Numsteps;
        private string[] steps;
        private string[] ingUnit;
        private string[] ingNames;
        private double[] ingQuan;
       
        public Recipe() { }

       public Recipe(int numING, int Numsteps, string[] ingNames, string [] ingUnit, string[] steps, double[] ingQuan) {
            this.numING = numING;
            this.ingNames = ingNames;
            this.ingQuan = ingQuan;
            this.ingUnit = ingUnit;
            this.Numsteps = Numsteps;
            this.steps = steps;
        }

        public void Details()
        {
            WriteLine("Enter the number of ingredients");
            numING = Convert.ToInt32(ReadLine());

            ingNames = new string[numING];
            ingQuan = new double[numING];
            ingUnit = new string[numING];
            for (int i = 0; i < numING; i++)
            {
                WriteLine("Enter name of ingredient {0} " , i+1);
                ingNames[i] = ReadLine();
                WriteLine("Enter the quantity");
                ingQuan[i] = Convert.ToDouble(ReadLine());
                WriteLine("Enter unit of measurement");
                ingUnit[i] = ReadLine();
            }
            WriteLine("Enter number of steps");
            Numsteps = Convert.ToInt32(Console.ReadLine());
            steps = new string[Numsteps];
            for (int i = 0; i < Numsteps; i++)
            {
                WriteLine("Enter step {0} ", i +1);
                steps[i] = ReadLine();
            }
        }
        public void Display()
        {
            WriteLine("Ingredients:");
            for (int i = 0; i < numING; i++)
            {
            WriteLine(ingQuan[i] +" "+ingUnit[i] +" "+ ingNames[i]);
            }

            WriteLine("Steps");
            for (int i = 0; i < Numsteps; i++)
            {
            WriteLine(i + 1 + " " + steps[i]);
            }
        }
        public void Scale(double scale)
        {
            
            for (int i = 0; i < numING; i++)
            {
                ingQuan[i] = ingQuan[i] * scale;
                WriteLine("\nScale is : " + ingQuan[i]);
            }
        }

        public void Reset()
        {
            for (int i = 0; i < numING; i++)
            {
                ingQuan[i] = ingQuan[i]/2;
                WriteLine("\nThe reset is : " + ingQuan[i]);
            }
        }

        public void Clear()
        {
            numING = 0;
            Numsteps = 0;
            ingNames = null;
            ingUnit = null;
            steps = null;
            ingQuan = null;
            WriteLine("\nEverything was cleared");
        }
    } 
}

